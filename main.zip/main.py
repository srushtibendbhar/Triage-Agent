import pandas as pd
import sys

# -------------------------------
# Arguments
# -------------------------------
if len(sys.argv) < 3:
    print("Usage: python code/main.py input.csv output.csv")
    sys.exit()

input_file = sys.argv[1]
output_file = sys.argv[2]

# -------------------------------
# Load CSV
# -------------------------------
df = pd.read_csv(input_file)
df.columns = df.columns.str.strip().str.lower()

# -------------------------------
# Clean Text (IMPORTANT FIX)
# -------------------------------
def clean_text(text):
    return str(text).replace("\n", " ").replace("\r", " ").strip()

# -------------------------------
# Classification
# -------------------------------
def classify_request(text):
    text = str(text).lower()

    if any(w in text for w in ["error", "failed", "bug", "crash"]):
        return "bug"
    elif any(w in text for w in ["feature", "add", "improve"]):
        return "feature_request"
    elif any(w in text for w in ["help", "how", "unable", "issue"]):
        return "product_issue"
    return "invalid"

# -------------------------------
# Product Area
# -------------------------------
def detect_product_area(text, company):
    text = str(text).lower()
    company = str(company).lower()

    if "visa" in company or "payment" in text:
        return "Visa Support"
    elif "hackerrank" in company or "test" in text:
        return "HackerRank"
    elif "claude" in company or "ai" in text:
        return "Claude"
    return "General"

# -------------------------------
# Risk Detection
# -------------------------------
def check_risk(text):
    text = str(text).lower()

    if any(w in text for w in ["fraud", "unauthorized", "hacked", "scam"]):
        return "high"
    return "low"

# -------------------------------
# Status
# -------------------------------
def decide_status(risk):
    return "escalated" if risk == "high" else "replied"

# -------------------------------
# Response (CLEAN)
# -------------------------------
def generate_response(status, request_type, product_area):
    if status == "escalated":
        return "This issue is sensitive and has been escalated to human support."

    if request_type == "bug":
        return "We’re sorry for the issue. Please try basic troubleshooting or retry."

    if request_type == "feature_request":
        return "Thanks for your suggestion. It has been shared with the team."

    if request_type == "product_issue":
        return f"Please check the {product_area} help section for guidance."

    return "This request is unclear or not supported."

# -------------------------------
# Justification
# -------------------------------
def generate_justification(status, request_type, risk):
    if status == "escalated":
        return "High-risk issue detected."
    return f"Low-risk {request_type}, safe to respond."

# -------------------------------
# Process Tickets
# -------------------------------
results = []

for i, row in df.iterrows():
    text = str(row.get("subject", "")) + " " + str(row.get("issue", ""))
    company = row.get("company", "")

    request_type = classify_request(text)
    product_area = detect_product_area(text, company)
    risk = check_risk(text)
    status = decide_status(risk)

    # CLEAN TEXT FIX APPLIED HERE
    response = clean_text(generate_response(status, request_type, product_area))
    justification = clean_text(generate_justification(status, request_type, risk))

    results.append({
        "status": status,
        "product_area": product_area,
        "request_type": request_type,
        "response": response,
        "justification": justification
    })

    # Clean terminal output
    print(f"\nTicket {i+1}")
    print("Status :", status)
    print("Area   :", product_area)
    print("Type   :", request_type)
    print("Reply  :", response)

# -------------------------------
# Save CSV (FIXED)
# -------------------------------
output_df = pd.DataFrame(results)

output_df = output_df[
    ["status", "product_area", "request_type", "response", "justification"]
]

output_df.to_csv(output_file, index=False, encoding="utf-8")

print("\n✅ Clean CSV saved to:", output_file)